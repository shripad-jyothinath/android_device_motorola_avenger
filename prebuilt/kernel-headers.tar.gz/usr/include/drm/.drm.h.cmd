cmd_usr/include/drm/drm.h := sh /serverhive/shripad/evox/kernel/motorola/sm7750/scripts/headers_install.sh /serverhive/shripad/evox/kernel/motorola/sm7750/include/uapi/drm/drm.h usr/include/drm/drm.h

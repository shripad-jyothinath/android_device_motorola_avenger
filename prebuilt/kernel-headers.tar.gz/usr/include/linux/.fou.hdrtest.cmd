cmd_usr/include/linux/fou.hdrtest := /serverhive/shripad/evox/vendor/lineage/build/tools/kernel_rbe_cc.sh clang -std=c90 -Wall -Werror=implicit-function-declaration --target=aarch64-linux-gnu -Wp,-MMD,usr/include/linux/.fou.hdrtest.d -I usr/include -I /serverhive/shripad/evox/kernel/motorola/sm7750/usr/dummy-include -fsyntax-only -x c /dev/null  -include usr/include/linux/fou.h -include usr/include/linux/fou.h; perl /serverhive/shripad/evox/kernel/motorola/sm7750/usr/include/headers_check.pl usr/include arm64 usr/include/linux/fou.h; touch usr/include/linux/fou.hdrtest

source_usr/include/linux/fou.hdrtest := /dev/null

deps_usr/include/linux/fou.hdrtest := \
  usr/include/linux/fou.h \

usr/include/linux/fou.hdrtest: $(deps_usr/include/linux/fou.hdrtest)

$(deps_usr/include/linux/fou.hdrtest):

cmd_usr/include/linux/version.h := sh /serverhive/shripad/evox/kernel/motorola/sm7750/scripts/headers_install.sh include/generated/uapi/linux/version.h usr/include/linux/version.h

cmd_usr/include/linux/utime.hdrtest := /serverhive/shripad/evox/vendor/lineage/build/tools/kernel_rbe_cc.sh clang -std=c90 -Wall -Werror=implicit-function-declaration --target=aarch64-linux-gnu -Wp,-MMD,usr/include/linux/.utime.hdrtest.d -I usr/include -I /serverhive/shripad/evox/kernel/motorola/sm7750/usr/dummy-include -fsyntax-only -x c /dev/null  -include usr/include/linux/utime.h -include usr/include/linux/utime.h; perl /serverhive/shripad/evox/kernel/motorola/sm7750/usr/include/headers_check.pl usr/include arm64 usr/include/linux/utime.h; touch usr/include/linux/utime.hdrtest

source_usr/include/linux/utime.hdrtest := /dev/null

deps_usr/include/linux/utime.hdrtest := \
  usr/include/linux/utime.h \
  usr/include/linux/types.h \
  usr/include/asm/types.h \
  usr/include/asm-generic/types.h \
  usr/include/asm-generic/int-ll64.h \
  usr/include/asm/bitsperlong.h \
  usr/include/asm-generic/bitsperlong.h \
    $(wildcard include/config/64BIT) \
  usr/include/linux/posix_types.h \
  usr/include/linux/stddef.h \
  usr/include/asm/posix_types.h \
  usr/include/asm-generic/posix_types.h \

usr/include/linux/utime.hdrtest: $(deps_usr/include/linux/utime.hdrtest)

$(deps_usr/include/linux/utime.hdrtest):

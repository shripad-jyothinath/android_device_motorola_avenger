cmd_usr/include/linux/uhid.hdrtest := /serverhive/shripad/evox/vendor/lineage/build/tools/kernel_rbe_cc.sh clang -std=c90 -Wall -Werror=implicit-function-declaration --target=aarch64-linux-gnu -Wp,-MMD,usr/include/linux/.uhid.hdrtest.d -I usr/include -I /serverhive/shripad/evox/kernel/motorola/sm7750/usr/dummy-include -fsyntax-only -x c /dev/null  -include usr/include/linux/uhid.h -include usr/include/linux/uhid.h; perl /serverhive/shripad/evox/kernel/motorola/sm7750/usr/include/headers_check.pl usr/include arm64 usr/include/linux/uhid.h; touch usr/include/linux/uhid.hdrtest

source_usr/include/linux/uhid.hdrtest := /dev/null

deps_usr/include/linux/uhid.hdrtest := \
  usr/include/linux/uhid.h \
  usr/include/linux/input.h \
  usr/include/linux/types.h \
  usr/include/asm/types.h \
  usr/include/asm-generic/types.h \
  usr/include/asm-generic/int-ll64.h \
  usr/include/asm/bitsperlong.h \
  usr/include/asm-generic/bitsperlong.h \
    $(wildcard include/config/64BIT) \
  usr/include/linux/posix_types.h \
  usr/include/linux/stddef.h \
  usr/include/asm/posix_types.h \
  usr/include/asm-generic/posix_types.h \
  usr/include/linux/input-event-codes.h \
  usr/include/linux/hid.h \

usr/include/linux/uhid.hdrtest: $(deps_usr/include/linux/uhid.hdrtest)

$(deps_usr/include/linux/uhid.hdrtest):
